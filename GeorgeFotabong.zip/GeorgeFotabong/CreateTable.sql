-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: CarRentals
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cars`
--

DROP TABLE IF EXISTS `cars`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cars` (
  `RegNum` varchar(10) NOT NULL,
  `TypeCode` varchar(2) NOT NULL,
  `Car_Description` varchar(10) NOT NULL,
  `Num_Seats` int(11) NOT NULL,
  `Car_Model` varchar(10) NOT NULL,
  `Car_Make` varchar(10) NOT NULL,
  `Fuel_Type` varchar(9) NOT NULL,
  `Car_Status` enum('A') DEFAULT 'A',
  PRIMARY KEY (`RegNum`),
  KEY `TypeCode` (`TypeCode`),
  KEY `Car_Make` (`Car_Make`,`Car_Model`),
  KEY `Fuel_Type` (`Fuel_Type`),
  CONSTRAINT `cars_ibfk_1` FOREIGN KEY (`TypeCode`) REFERENCES `cartypes` (`TypeCode`),
  CONSTRAINT `cars_ibfk_2` FOREIGN KEY (`Car_Make`, `Car_Model`) REFERENCES `makemodels` (`Make`, `Model`),
  CONSTRAINT `cars_ibfk_3` FOREIGN KEY (`Fuel_Type`) REFERENCES `makemodels` (`Fuel_Type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cars`
--

LOCK TABLES `cars` WRITE;
/*!40000 ALTER TABLE `cars` DISABLE KEYS */;
INSERT INTO `cars` VALUES ('ABCDE12','FM','Sedan',5,'Yaris','Toyota','Gasoline','A'),('FGHIJ34','SP','SUV',7,'Corsa','Opel','Diesel','A'),('KLMNO56','EL','Electric',5,'A4','Audi','CNG','A'),('PQRST78','EC','Compact',5,'X5','BMW','Biodiesel','A'),('UVWXY90','HV','Hatchback',5,'Tucson','Hyundai','Electric','A');
/*!40000 ALTER TABLE `cars` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cartypes`
--

DROP TABLE IF EXISTS `cartypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cartypes` (
  `TypeCode` varchar(2) NOT NULL,
  `Type_Description` varchar(10) NOT NULL,
  `Rate` decimal(5,2) NOT NULL,
  PRIMARY KEY (`TypeCode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cartypes`
--

LOCK TABLES `cartypes` WRITE;
/*!40000 ALTER TABLE `cartypes` DISABLE KEYS */;
INSERT INTO `cartypes` VALUES ('BB','Basic',999.99),('CM','Compact',80.00),('DL','Deluxe',150.00),('EC','ECO',30.00),('EL','Electric',200.00),('EV','Electric V',200.00),('FM','FAMILY',80.00),('HV','Hybrid Veh',100.00),('PM','PREMIUM',100.00),('SP','Special',100.00),('SU','Sport Util',120.00);
/*!40000 ALTER TABLE `cartypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customers` (
  `CustID` int(11) NOT NULL AUTO_INCREMENT,
  `Forename` varchar(30) NOT NULL,
  `Surname` varchar(30) NOT NULL,
  `Email` varchar(30) NOT NULL,
  `Phone_Num` varchar(12) NOT NULL,
  `Licence_Num` varchar(9) NOT NULL,
  PRIMARY KEY (`CustID`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers`
--

LOCK TABLES `customers` WRITE;
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
INSERT INTO `customers` VALUES (1,'Mik','Fotabong','GeorgeFotabong52@gmail.com','2899370842','12345678'),(2,'John','Doe','johndoe@example.com','1234567890','87654321'),(3,'Jane','Smith','janesmith@example.com','0987654321','12349876'),(4,'Alice','Johnson','alicejohnson@example.com','5556667777','65432198'),(5,'Bob','Brown','bobbrown@example.com','4443332222','98765432'),(6,'Emily','Davis','emilydavis@example.com','2225558888','13579246');
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `makemodels`
--

DROP TABLE IF EXISTS `makemodels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `makemodels` (
  `Make` varchar(15) NOT NULL,
  `Model` varchar(15) NOT NULL,
  `Fuel_Type` varchar(9) NOT NULL,
  PRIMARY KEY (`Make`,`Model`),
  UNIQUE KEY `Fuel_Type` (`Fuel_Type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `makemodels`
--

LOCK TABLES `makemodels` WRITE;
/*!40000 ALTER TABLE `makemodels` DISABLE KEYS */;
INSERT INTO `makemodels` VALUES ('BMW','X5','Biodiesel'),('Audi','A4','CNG'),('OPEL','CORSA','Diesel'),('HYUNDAI','TUCSON','Electric'),('Lexus','RX','Ethanol'),('Mercedes','C-Class','Gas'),('TOYOTA','COROLLA','Gasoline'),('TOYOTA','YARIS','Hybrid'),('OPEL','ASTRA','LPG');
/*!40000 ALTER TABLE `makemodels` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rentals`
--

DROP TABLE IF EXISTS `rentals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rentals` (
  `Rental_Number` int(11) NOT NULL AUTO_INCREMENT,
  `RegNum` varchar(10) NOT NULL,
  `TypeCode` varchar(2) NOT NULL,
  `RentStart` date NOT NULL,
  `ReturnDate` date NOT NULL,
  `RentStartTime` varchar(5) NOT NULL,
  `RentEndTime` varchar(5) NOT NULL,
  `Amount` decimal(5,2) NOT NULL,
  `CustID` int(11) NOT NULL,
  `Customer_Status` enum('P') DEFAULT 'P',
  PRIMARY KEY (`Rental_Number`),
  KEY `CustID` (`CustID`),
  KEY `RegNum` (`RegNum`),
  KEY `TypeCode` (`TypeCode`),
  CONSTRAINT `rentals_ibfk_1` FOREIGN KEY (`CustID`) REFERENCES `customers` (`CustID`),
  CONSTRAINT `rentals_ibfk_2` FOREIGN KEY (`RegNum`) REFERENCES `cars` (`RegNum`),
  CONSTRAINT `rentals_ibfk_3` FOREIGN KEY (`TypeCode`) REFERENCES `cartypes` (`TypeCode`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rentals`
--

LOCK TABLES `rentals` WRITE;
/*!40000 ALTER TABLE `rentals` DISABLE KEYS */;
INSERT INTO `rentals` VALUES (37,'ABCDE12','FM','2024-04-27','2024-04-28','18:15','19:15',160.00,1,'P');
/*!40000 ALTER TABLE `rentals` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-04-27 18:17:58
