<?php
try { 
    $pdo = new PDO('mysql:host=localhost;dbname=CarRentals;charset=utf8', 'root', ''); 
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $sql = 'SELECT * FROM Customers';
    $result = $pdo->query($sql); 
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Customer Information</title>
  <link rel="stylesheet" type="text/css" href="car_rental.css"> 
</head>
<body>
    <div class="container">
        <h1>A Quick View</h1>
        <table class="customer-table"> 
            <tr>
                <th>Customer ID</th>
                <th>Name</th>
                <th>Email</th>
            </tr>
  
<?php
    while ($row = $result->fetch()):
?>
            <tr>
                <td><?php echo $row['CustID']; ?></td>
                <td><?php echo $row['Forename'] . ' ' . $row['Surname']; ?></td>
                <td><?php echo $row['Email']; ?></td>
            </tr>
<?php
    endwhile;
?>
        </table>
    </div> 

<?php
} 
catch (PDOException $e) { 
    $output = 'Unable to connect to the database server: ' . $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine(); 
}
include 'whotoupdate.html';
?>

</body>
</html>



