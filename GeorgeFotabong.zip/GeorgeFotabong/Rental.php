<?php
try { 
    $pdo = new PDO('mysql:host=localhost;dbname=carRentals;charset=utf8', 'root', ''); 
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $sql = 'SELECT * FROM Customers';
    $result = $pdo->query($sql); 
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customer List</title>
    <link rel="stylesheet" href="car_rental.css">
</head>
<body>
    <div class="container">
        <div class="topnav">
            <h1>Rentals</h1>
        </div>
        
        <table>
                <tr>
                    <th>Customer Id </th>
                    <th> First Name </th>
                    <th> Actions</th>
                </tr>
                <?php while ($row = $result->fetch()) { ?>
                <tr>
                    <td><?php echo $row['CustID']; ?></td>
                    <td><?php echo $row['Forename']; ?></td>
                    <td class="actions">
                        <a href="MakeRental.php?CustID=<?php echo $row['CustID']; ?>">Make Rental</a>
                        <a href="DeleteRental.html?CustID=<?php echo $row['CustID']; ?>">Cancel Rental</a>
                    </td>
                </tr>
                <?php } ?>
        </table>
    </div>
</body>
</html>

<?php
} catch (PDOException $e) { 
    $output = 'Unable to connect to the database server: ' . $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine(); 
}
?>

